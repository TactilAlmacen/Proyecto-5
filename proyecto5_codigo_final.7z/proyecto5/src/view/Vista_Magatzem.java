/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import Controller.Controller;
import java.awt.Image;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import model.Categoria;
import model.Conexio;
import model.Estoc;
import model.InfoTaula;
import model.Lloc;
import model.ProdLlocEstoc;
import model.Prod_Lloc_Estoc;
import model.Producte;
import model.Serie;

/**
 *
 * @author zuh19
 */
public class Vista_Magatzem extends javax.swing.JFrame {

    ArrayList<Prod_Lloc_Estoc> mostrar_all = new ArrayList<Prod_Lloc_Estoc>();
    
    Conexio conexion = new Conexio();
    Connection con = conexion.conectar();
    Controller controller = new Controller();
    Producte producte = new Producte();
    
    Lloc lloc = new Lloc();
    Estoc estoc = new Estoc();
    
    int j=0;
    
    public Vista_Magatzem() {
        initComponents();
        iniciar();
    }
       
    public void iniciar(){
        mostrar_all.clear();
        panel_estoc.setVisible(false);
        label_info.setVisible(false);
        btn_guardar.setVisible(false);
        opc_combobox();
        activar_desactivar(true);
        mostrar_all.clear();
        mostrar_all=controller.AllProd();
        mostrar(j);
        btn_verestoc.setText("Visualitzar estoc");
        btn_mostrar.setVisible(false);
        tbl_prod.setModel(controller.mostrarproductos((DefaultTableModel)this.tbl_prod.getModel()));
        tbl_prod.getColumnModel().getColumn(4).setPreferredWidth(10);
        tbl_prod.getColumnModel().getColumn(3).setPreferredWidth(30);
        tbl_prod.getColumnModel().getColumn(2).setPreferredWidth(80);
        tbl_prod.getColumnModel().getColumn(1).setPreferredWidth(100);
        tbl_prod.getColumnModel().getColumn(0).setMaxWidth(0);
        tbl_prod.getColumnModel().getColumn(0).setMinWidth(0);
        tbl_prod.getColumnModel().getColumn(0).setPreferredWidth(0);
    }
    
    public Boolean validar_modif(String nom,String desc,String preu,String descompte){
        Boolean result=true;
        if(preu.length()==0 || preu.length()==1){
            JOptionPane.showMessageDialog(null,"Un producte no pot tenir un preu tan baix, introdueixi una quantitat vàlida");
            result=false;
        }else if(desc.isEmpty()==true || nom.isEmpty()==true || descompte.isEmpty()==true){
            JOptionPane.showMessageDialog(null,"Ompli tots els camps");
            result=false;
        }else if(nom.length()==3){
            JOptionPane.showMessageDialog(null,"Introduieixi un nom de producte vàlid.");
            result=false;
        }else if(descompte=="100"){
            JOptionPane.showMessageDialog(null,"No es pot introduir un descompte del 100%");
            result=false;
        }
        return result;
    }
    
    public void opc_combobox(){
        try {
            cb_categoria.addItem("Qualsevol");
            String sql="SELECT categoria_nom FROM tbl_categoria";
            Statement st;
            
            st=con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            
            while(rs.next()){
                String opc=rs.getString("categoria_nom");
                cb_categoria.addItem(opc);
            }
            
        } catch (Exception e) {
        }
    }
    
    public void opc_modificar(){
        try {
            String sql="SELECT DISTINCT num_bloc FROM tbl_lloc ORDER BY num_bloc";
            Statement st;
            Statement st1;
            Statement st2;
            Statement st3;
            
            st=con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            
            while(rs.next()){
                String opc=rs.getString("num_bloc");
                cb_bloc.addItem(opc);
            }
            
            sql="SELECT DISTINCT num_passadis FROM tbl_lloc ORDER BY num_passadis";
            st1=con.createStatement();
            rs = st1.executeQuery(sql);
            while(rs.next()){
                String opc=rs.getString("num_passadis");
                cb_passadis.addItem(opc);
            }
            
            sql="SELECT DISTINCT num_lleixa FROM tbl_lloc ORDER BY num_lleixa";
            st2=con.createStatement();
            rs = st2.executeQuery(sql);
            while(rs.next()){
                String opc=rs.getString("num_lleixa");
                cb_lleixa.addItem(opc);
            }
            
            sql="SELECT DISTINCT categoria_nom FROM tbl_categoria ORDER BY categoria_nom";
            st3=con.createStatement();
            rs = st3.executeQuery(sql);
            while(rs.next()){
                String opc=rs.getString("categoria_nom");
                jc_categoria.addItem(opc);
            }
        } catch (Exception e) {
        }
    }
    
    public void activar_desactivar(boolean t){
        this.btn_ultim.setEnabled(t);
        this.btn_seguent.setEnabled(t);
        this.btn_primer.setEnabled(!t);
        this.btn_anterior.setEnabled(!t);
        
    }
    
    public void modificar(boolean s){
        jt_nom.setEditable(s);
        jt_desc.setEditable(s);
        jt_preu.setEditable(s);
        jt_descompte.setEditable(s);
        cb_bloc.setEnabled(s);
        cb_lleixa.setEnabled(s);
        cb_passadis.setEnabled(s);
        jc_categoria.setEnabled(s);
        jt_serie.setEditable(s);
        if(s==true){
            opc_modificar();
            jt_nom.requestFocusInWindow();
            btn_modif.setText("Cancelar");
        }else{
            btn_modif.setText("Modificar producte");
            label_info.setVisible(false);
        }
        btn_guardar.setVisible(s);
        label_info.setVisible(s);
    }
    
    public void mostrar(int index){
        if(index==mostrar_all.size()-1){
            this.btn_ultim.setEnabled(false);
            this.btn_seguent.setEnabled(false);
        }else{
            this.btn_ultim.setEnabled(true);
            this.btn_seguent.setEnabled(true);
        }
        if(index==0){
            this.btn_primer.setEnabled(false);
            this.btn_anterior.setEnabled(false);
        }else{
            this.btn_primer.setEnabled(true);
            this.btn_anterior.setEnabled(true);
        }
        
        if(jc_categoria.isEnabled()){
            modificar(false);
        }
        /*Producte*/
        
        this.jt_nom.setText(mostrar_all.get(index).getP().getNom());
        this.jt_desc.setText(mostrar_all.get(index).getP().getDesc());
        this.jt_preu.setText(String.valueOf(mostrar_all.get(index).getP().getPreu()));
        this.jt_descompte.setText(String.valueOf(mostrar_all.get(index).getP().getDescompte()));
        String ruta = "/img/" + mostrar_all.get(index).getP().getFoto();
        label_foto.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource(ruta)).getImage().getScaledInstance(180, 180, Image.SCALE_SMOOTH)));
        
        Double precio= mostrar_all.get(index).getP().getPreu();
        Integer descuento=mostrar_all.get(index).getP().getDescompte();
        Double con_desc=precio*descuento/100;
        Double result=precio-con_desc;
        BigDecimal a = new BigDecimal(result);
        BigDecimal roundOff = a.setScale(2, BigDecimal.ROUND_HALF_EVEN);
        this.jt_condesc.setText(String.valueOf(roundOff));
        
        /*Lloc*/
        
        this.cb_bloc.getModel().setSelectedItem(mostrar_all.get(index).getL().getNumbloc());
        this.cb_passadis.getModel().setSelectedItem(mostrar_all.get(index).getL().getPassadis());
        this.cb_lleixa.getModel().setSelectedItem(mostrar_all.get(index).getL().getLleixa());
        
        /*Categoria*/
        String categoria=(mostrar_all.get(index).getC().getCategoria_nom());
        this.jc_categoria.getModel().setSelectedItem(categoria);
        /*Serie*/
        
        this.jt_serie.setText(mostrar_all.get(index).getS().getSerie_nom());
        
        /*Estoc*/
        
        this.jt_maxim.setText(String.valueOf(mostrar_all.get(index).getE().getMax()));
        this.jt_minim.setText(String.valueOf(mostrar_all.get(index).getE().getMin()));
        this.jt_actual.setText(String.valueOf(mostrar_all.get(index).getE().getActual()));
        this.jt_estoc.setText("5");
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jt_nom = new javax.swing.JTextField();
        jt_preu = new javax.swing.JTextField();
        jt_descompte = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_prod = new javax.swing.JTable();
        jt_cercar = new javax.swing.JTextField();
        btn_cercar = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        label_foto = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        btn_mostrar = new javax.swing.JButton();
        btn_primer = new javax.swing.JButton();
        btn_anterior = new javax.swing.JButton();
        btn_seguent = new javax.swing.JButton();
        btn_ultim = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jt_condesc = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        cb_categoria = new javax.swing.JComboBox<>();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jt_desc = new javax.swing.JTextArea();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        label_info = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        btn_modif = new javax.swing.JButton();
        btn_guardar = new javax.swing.JButton();
        btn_eliminar = new javax.swing.JButton();
        btn_verestoc = new javax.swing.JButton();
        panel_estoc = new javax.swing.JPanel();
        jt_maxim = new javax.swing.JTextField();
        jt_estoc = new javax.swing.JTextField();
        jt_minim = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jt_actual = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        btn_agregar = new javax.swing.JButton();
        btn_restar = new javax.swing.JButton();
        jc_categoria = new javax.swing.JComboBox<>();
        jLabel21 = new javax.swing.JLabel();
        jt_serie = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        cb_bloc = new javax.swing.JComboBox<>();
        cb_passadis = new javax.swing.JComboBox<>();
        cb_lleixa = new javax.swing.JComboBox<>();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        opt_crear = new javax.swing.JMenuItem();
        cerrarsesio = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        Cerrar = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel1.setText("Nom:");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel2.setText("Descripció:");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel3.setText("Preu:");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel4.setText("Descompte:");

        jt_nom.setEditable(false);

        jt_preu.setEditable(false);
        jt_preu.setToolTipText("Mostrat en €");

        jt_descompte.setEditable(false);
        jt_descompte.setToolTipText("");

        tbl_prod.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Nom", "Categoria", "Sèrie", "Preu"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_prod.setUpdateSelectionOnSort(false);
        tbl_prod.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_prodMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_prod);

        jt_cercar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jt_cercarActionPerformed(evt);
            }
        });

        btn_cercar.setText("Cercar");
        btn_cercar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cercarActionPerformed(evt);
            }
        });

        jLabel8.setText("Nom:");

        jPanel1.setBackground(new java.awt.Color(153, 153, 153));

        label_foto.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(label_foto, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(label_foto, javax.swing.GroupLayout.DEFAULT_SIZE, 180, Short.MAX_VALUE)
        );

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel9.setText("INFORMACIÓ PRODUCTE");

        jLabel5.setText("€");

        jLabel6.setText("%");

        btn_mostrar.setText("Mostrar todos los productos");
        btn_mostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_mostrarActionPerformed(evt);
            }
        });

        btn_primer.setText("<<");
        btn_primer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_primerActionPerformed(evt);
            }
        });

        btn_anterior.setText("<");
        btn_anterior.setToolTipText("");
        btn_anterior.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_anteriorActionPerformed(evt);
            }
        });

        btn_seguent.setText(">");
        btn_seguent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_seguentActionPerformed(evt);
            }
        });

        btn_ultim.setText(">>");
        btn_ultim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ultimActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel7.setText("Preu final:");

        jt_condesc.setEditable(false);
        jt_condesc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jt_condescActionPerformed(evt);
            }
        });

        jLabel10.setText("€");

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel11.setText("CERCADOR");

        jLabel12.setText("Categoria:");

        jt_desc.setEditable(false);
        jt_desc.setColumns(20);
        jt_desc.setLineWrap(true);
        jt_desc.setRows(5);
        jScrollPane2.setViewportView(jt_desc);

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel14.setText("Bloc:");
        jLabel14.setToolTipText("");

        jLabel15.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel15.setText("Passadís:");
        jLabel15.setToolTipText("");

        jLabel16.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel16.setText("Lleixa:");
        jLabel16.setToolTipText("");

        label_info.setForeground(new java.awt.Color(255, 0, 0));
        label_info.setText("Es calcula automàticament");

        btn_modif.setText("Modificar producte");
        btn_modif.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_modifActionPerformed(evt);
            }
        });

        btn_guardar.setText("Guardar canvis");
        btn_guardar.setToolTipText("");
        btn_guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_guardarActionPerformed(evt);
            }
        });

        btn_eliminar.setText("Eliminar producte");
        btn_eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_eliminarActionPerformed(evt);
            }
        });

        btn_verestoc.setText("Visualitzar estoc");
        btn_verestoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_verestocActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(22, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btn_guardar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(btn_eliminar, javax.swing.GroupLayout.DEFAULT_SIZE, 186, Short.MAX_VALUE)
                        .addComponent(btn_verestoc, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(btn_modif, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btn_modif)
                .addGap(11, 11, 11)
                .addComponent(btn_guardar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_eliminar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                .addComponent(btn_verestoc))
        );

        jt_maxim.setEditable(false);
        jt_maxim.setOpaque(false);

        jt_estoc.setText("5");
        jt_estoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jt_estocActionPerformed(evt);
            }
        });
        jt_estoc.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jt_estocKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jt_estocKeyTyped(evt);
            }
        });

        jt_minim.setEditable(false);
        jt_minim.setOpaque(false);

        jLabel17.setText("Estoc màxim");

        jLabel19.setText("Estoc mínim");

        jLabel20.setText("Estoc actual");

        jt_actual.setEditable(false);
        jt_actual.setOpaque(false);

        jLabel23.setText("Restar/Agregar estoc");

        btn_agregar.setText("Agregar");
        btn_agregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_agregarActionPerformed(evt);
            }
        });

        btn_restar.setText("Restar");
        btn_restar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_restarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panel_estocLayout = new javax.swing.GroupLayout(panel_estoc);
        panel_estoc.setLayout(panel_estocLayout);
        panel_estocLayout.setHorizontalGroup(
            panel_estocLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_estocLayout.createSequentialGroup()
                .addGroup(panel_estocLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel_estocLayout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addGroup(panel_estocLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel20)
                            .addComponent(jLabel19)
                            .addComponent(jLabel17)))
                    .addGroup(panel_estocLayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jLabel23)))
                .addGap(18, 18, 18)
                .addGroup(panel_estocLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jt_estoc)
                    .addComponent(jt_minim)
                    .addComponent(jt_actual)
                    .addComponent(jt_maxim))
                .addGap(23, 23, 23))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_estocLayout.createSequentialGroup()
                .addGap(0, 40, Short.MAX_VALUE)
                .addComponent(btn_restar, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_agregar)
                .addGap(34, 34, 34))
        );
        panel_estocLayout.setVerticalGroup(
            panel_estocLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_estocLayout.createSequentialGroup()
                .addGroup(panel_estocLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel_estocLayout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(panel_estocLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel20)
                            .addComponent(jt_actual, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panel_estocLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(panel_estocLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jt_maxim, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel17))
                        .addGap(29, 29, 29)
                        .addGroup(panel_estocLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jt_minim, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel19))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_estocLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jt_estoc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel23))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panel_estocLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_restar)
                    .addComponent(btn_agregar))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jc_categoria.setEnabled(false);
        jc_categoria.setFocusable(false);

        jLabel21.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel21.setText("Categoria:");

        jt_serie.setEditable(false);

        jLabel22.setText("Sèrie:");

        cb_bloc.setEnabled(false);
        cb_bloc.setFocusable(false);

        cb_passadis.setEnabled(false);
        cb_passadis.setFocusable(false);

        cb_lleixa.setEnabled(false);
        cb_lleixa.setFocusable(false);

        jMenu1.setText("Opcions");

        opt_crear.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.CTRL_MASK));
        opt_crear.setText("Crear usuari");
        opt_crear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opt_crearActionPerformed(evt);
            }
        });
        jMenu1.add(opt_crear);

        cerrarsesio.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_X, java.awt.event.InputEvent.SHIFT_MASK));
        cerrarsesio.setText("Tancar Sesió");
        cerrarsesio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cerrarsesioActionPerformed(evt);
            }
        });
        jMenu1.add(cerrarsesio);
        jMenu1.add(jSeparator1);

        Cerrar.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_X, java.awt.event.InputEvent.CTRL_MASK));
        Cerrar.setText("Cerrar Aplicació");
        Cerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CerrarActionPerformed(evt);
            }
        });
        jMenu1.add(Cerrar);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(193, 193, 193)
                        .addComponent(jLabel9))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(86, 86, 86)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel2)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel1)
                                        .addGap(10, 10, 10))))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(116, 116, 116)
                                .addComponent(jLabel3))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(46, 46, 46)
                                .addComponent(jLabel4)))
                        .addGap(70, 70, 70)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jt_nom)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(92, 92, 92)
                        .addComponent(btn_primer)
                        .addGap(42, 42, 42)
                        .addComponent(btn_anterior)
                        .addGap(50, 50, 50)
                        .addComponent(btn_seguent)
                        .addGap(48, 48, 48)
                        .addComponent(btn_ultim))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(94, 94, 94)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel14)
                            .addComponent(jLabel16)
                            .addComponent(jLabel21)
                            .addComponent(jLabel22)
                            .addComponent(jLabel7))
                        .addGap(68, 68, 68)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jc_categoria, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(cb_bloc, javax.swing.GroupLayout.Alignment.LEADING, 0, 111, Short.MAX_VALUE)
                                .addComponent(cb_passadis, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(cb_lleixa, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jt_descompte, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 79, Short.MAX_VALUE)
                                    .addComponent(jt_preu, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jt_condesc, javax.swing.GroupLayout.Alignment.LEADING))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(label_info))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(217, 217, 217)
                        .addComponent(jt_serie, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panel_estoc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(btn_cercar)
                                .addGap(46, 46, 46))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(92, 92, 92)
                                    .addComponent(jLabel11))
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel8)
                                        .addComponent(jLabel12))
                                    .addGap(28, 28, 28)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(cb_categoria, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jt_cercar, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(154, 154, 154))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 410, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(btn_mostrar)
                                .addGap(106, 106, 106)))
                        .addGap(26, 26, 26))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(13, 13, 13)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(panel_estoc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jt_cercar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel8))
                                .addGap(26, 26, 26))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel12)
                                .addComponent(cb_categoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(13, 13, 13)
                        .addComponent(btn_cercar)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(btn_mostrar)
                        .addGap(42, 42, 42))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addGap(30, 30, 30)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel2))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jt_nom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(5, 5, 5)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel5)
                                    .addComponent(jt_preu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jt_descompte, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel6))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jt_condesc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel10)
                                    .addComponent(label_info))
                                .addGap(8, 8, 8))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel7)
                                .addGap(12, 12, 12)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel14))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(3, 3, 3)
                                .addComponent(cb_bloc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel15)
                                    .addComponent(cb_passadis, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel16)
                                    .addComponent(cb_lleixa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel21)
                            .addComponent(jc_categoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jt_serie, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel22))
                        .addGap(44, 44, 44)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_primer)
                            .addComponent(btn_anterior)
                            .addComponent(btn_seguent)
                            .addComponent(btn_ultim))
                        .addContainerGap(85, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jt_cercarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jt_cercarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jt_cercarActionPerformed

    private void tbl_prodMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_prodMouseClicked
        // TODO add your handling code here:
        
        int index =tbl_prod.getSelectedRow();
        TableModel model= tbl_prod.getModel();
        String id_col=model.getValueAt(index,0).toString();
        String nombre_col=model.getValueAt(index,1).toString();
        String categoria_col=model.getValueAt(index,2).toString();
        String serie_col=model.getValueAt(index,3).toString();
        
        Integer row = tbl_prod.rowAtPoint(evt.getPoint());
        /*DefaultTableModel modelo=(DefaultTableModel)this.tbl_prod.getModel();
        Integer res=controller.clicktable(modelo, row, id_col);*/
        j=row;
        mostrar(j);
    }//GEN-LAST:event_tbl_prodMouseClicked

    private void btn_cercarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cercarActionPerformed
        // TODO add your handling code here:
        String nombre=jt_cercar.getText();
        String select=cb_categoria.getSelectedItem().toString();
        
        if((nombre.length()==0 ||nombre==null) && (select=="Qualsevol")){
            JOptionPane.showMessageDialog(null, "Per a cercar productes, abans seleccioni algún filtre");   
        }else{
            btn_mostrar.setVisible(true);
            String cerca=jt_cercar.getText();
            mostrar_all=controller.cercar((DefaultTableModel)this.tbl_prod.getModel(),cerca,select);
            j=0;
            mostrar(j);
        }
    }//GEN-LAST:event_btn_cercarActionPerformed

    private void btn_mostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_mostrarActionPerformed
        // TODO add your handling code here:
        mostrar_all.clear();
        mostrar_all=controller.AllProd();
        controller.mostrarproductos((DefaultTableModel)this.tbl_prod.getModel());
        j=0;
        mostrar(j);
        btn_mostrar.setVisible(false);
        jt_cercar.setText("");
    }//GEN-LAST:event_btn_mostrarActionPerformed

    private void btn_primerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_primerActionPerformed
        // TODO add your handling code here:
        activar_desactivar(true);
        j=0;
        mostrar(j);
    }//GEN-LAST:event_btn_primerActionPerformed

    private void btn_seguentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_seguentActionPerformed
        // TODO add your handling code here:
        j++;
        mostrar(j);
        if(j==mostrar_all.size()-1){
            activar_desactivar(false);
        }else{
            this.btn_ultim.setEnabled(true);
            this.btn_seguent.setEnabled(true);
            this.btn_primer.setEnabled(true);
            this.btn_anterior.setEnabled(true);
        }
    }//GEN-LAST:event_btn_seguentActionPerformed

    private void btn_anteriorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_anteriorActionPerformed
        // TODO add your handling code here:
        j--;
        mostrar(j);
        if(j==0){
            activar_desactivar(true);
        }else{
            this.btn_ultim.setEnabled(true);
            this.btn_seguent.setEnabled(true);
            this.btn_primer.setEnabled(true);
            this.btn_anterior.setEnabled(true);
        }
    }//GEN-LAST:event_btn_anteriorActionPerformed

    private void btn_ultimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ultimActionPerformed
        // TODO add your handling code here:
        j=mostrar_all.size()-1;
        mostrar(j);
        activar_desactivar(false);
    }//GEN-LAST:event_btn_ultimActionPerformed

    private void btn_modifActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_modifActionPerformed
        // TODO add your handling code here:
        String btn=btn_modif.getText();
        if(btn=="Modificar producte"){
            modificar(true);
        }else{
            modificar(false);
            mostrar(j);
        }
    }//GEN-LAST:event_btn_modifActionPerformed

    private void btn_guardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_guardarActionPerformed
        // TODO add your handling code here:
        String nom=jt_nom.getText();
        String desc=jt_desc.getText();
        String preu=jt_preu.getText();
        String descompte=jt_descompte.getText();
        Integer id=mostrar_all.get(j).getP().getId();
        String bloc =cb_bloc.getSelectedItem()+"";
        String passadis =cb_passadis.getSelectedItem()+"";
        String lleixa =cb_lleixa.getSelectedItem()+"";
        String categoria =jc_categoria.getSelectedItem()+"";
        String serie=jt_serie.getText();
        boolean ok=validar_modif(nom,desc,preu,descompte);
        if(ok==true){
            boolean result=controller.modificar_producte(nom,desc,preu,descompte,bloc,passadis,lleixa,categoria,serie,String.valueOf(id));
            if(result=true){
                JOptionPane.showMessageDialog(null,"S'ha modificat aquest producte amb èxit");
                mostrar_all.clear();
                mostrar_all=controller.AllProd();
                mostrar(j);
                jt_nom.setEditable(false);
                jt_desc.setEditable(false);
                jt_preu.setEditable(false);
                jt_descompte.setEditable(false);
                btn_modif.setText("Modificar producte");
                btn_guardar.setVisible(false);
                mostrar(j);
                label_info.setVisible(false);
            }else{
                JOptionPane.showMessageDialog(null,"Error");
            }
        }
    }//GEN-LAST:event_btn_guardarActionPerformed

    private void jt_condescActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jt_condescActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jt_condescActionPerformed

    private void opt_crearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opt_crearActionPerformed
        // TODO add your handling code here:
        Vista_Registre frame = new Vista_Registre();
        this.setVisible(false);
        frame.setVisible(true);
    }//GEN-LAST:event_opt_crearActionPerformed

    private void btn_eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_eliminarActionPerformed
        // TODO add your handling code here:
        String id=String.valueOf(mostrar_all.get(j).getP().getId());
        controller.eliminar(id);
        iniciar();
        j=0;
        mostrar(j);
        
    }//GEN-LAST:event_btn_eliminarActionPerformed

    private void btn_verestocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_verestocActionPerformed
        // TODO add your handling code here:
        if(btn_verestoc.getText()=="Visualitzar estoc"){
            btn_verestoc.setText("Ocultar botó estoc");
            panel_estoc.setVisible(true);
        }else{
            btn_verestoc.setText("Visualitzar estoc");
            panel_estoc.setVisible(false);
        }
    }//GEN-LAST:event_btn_verestocActionPerformed

    private void jt_estocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jt_estocActionPerformed
        // TODO add your handling code here:
       
    }//GEN-LAST:event_jt_estocActionPerformed

    private void jt_estocKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jt_estocKeyTyped
        // TODO add your handling code here:
        char c=evt.getKeyChar();
        if(c<'0' || c>'9') evt.consume();
    }//GEN-LAST:event_jt_estocKeyTyped

    private void jt_estocKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jt_estocKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jt_estocKeyPressed

    private void btn_restarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_restarActionPerformed
        // TODO add your handling code here:
        Integer max=Integer.valueOf(jt_maxim.getText());
        Integer min=Integer.valueOf(jt_minim.getText());
        Integer actual=Integer.valueOf(jt_actual.getText());
        Integer restar=Integer.valueOf(jt_estoc.getText());
        Integer r=actual-restar;
        boolean ok=true;
        if(r<min){
            JOptionPane.showMessageDialog(null,"La quantitat que vol restar a l'estoc supera el mínim");
            ok=false;
        }else if(restar==0){
            JOptionPane.showMessageDialog(null,"Introdueixi una quantitat vàlida");
            ok=false;
        }else if (jt_estoc.getText().isEmpty()==true){
            JOptionPane.showMessageDialog(null,"Per restar estoc introdueixi un número");
            ok=false;
        }
        Integer id=mostrar_all.get(j).getP().getId();
        if(ok==true){
            restar=actual-restar;
            controller.restar_estoc(restar,id);
            tbl_prod.setModel(controller.mostrarproductos((DefaultTableModel)this.tbl_prod.getModel()));
            iniciar();
            panel_estoc.setVisible(true);
            btn_verestoc.setText("Ocultar botó estoc");
        }
    }//GEN-LAST:event_btn_restarActionPerformed

    private void btn_agregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_agregarActionPerformed
        // TODO add your handling code here:
        Integer max=Integer.valueOf(jt_maxim.getText());
        Integer min=Integer.valueOf(jt_minim.getText());
        Integer actual=Integer.valueOf(jt_actual.getText());
        Integer agregar=Integer.valueOf(jt_estoc.getText());
        Integer r=actual+agregar;
        boolean ok=true;
        if(r>max){
            ok=false;
            JOptionPane.showMessageDialog(null,"La quantitat que vol agregar a l'estoc supera el màxim");
        }else if(agregar==0){
            ok=false;
            JOptionPane.showMessageDialog(null,"Introdueixi una quantitat vàlida");
        }else if (jt_estoc.getText().isEmpty()==true){
            ok=false;
            JOptionPane.showMessageDialog(null,"Per agregar estoc introdueixi un número");
        }
        Integer id=mostrar_all.get(j).getP().getId();
        agregar=agregar+actual;
         if(ok==true){
            controller.sumar_estoc(agregar,id);
            iniciar();
            panel_estoc.setVisible(true);
            btn_verestoc.setText("Ocultar botó estoc");
        }
    }//GEN-LAST:event_btn_agregarActionPerformed

    private void cerrarsesioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cerrarsesioActionPerformed
        // TODO add your handling code here:
        Vista_Login frame = new Vista_Login();
        this.setVisible(false);
        frame.setVisible(true);
    }//GEN-LAST:event_cerrarsesioActionPerformed

    private void CerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CerrarActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_CerrarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Vista_Magatzem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Vista_Magatzem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Vista_Magatzem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Vista_Magatzem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Vista_Magatzem().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem Cerrar;
    private javax.swing.JButton btn_agregar;
    private javax.swing.JButton btn_anterior;
    private javax.swing.JButton btn_cercar;
    private javax.swing.JButton btn_eliminar;
    private javax.swing.JButton btn_guardar;
    private javax.swing.JButton btn_modif;
    private javax.swing.JButton btn_mostrar;
    private javax.swing.JButton btn_primer;
    private javax.swing.JButton btn_restar;
    private javax.swing.JButton btn_seguent;
    private javax.swing.JButton btn_ultim;
    private javax.swing.JButton btn_verestoc;
    private javax.swing.JComboBox<String> cb_bloc;
    private javax.swing.JComboBox<String> cb_categoria;
    private javax.swing.JComboBox<String> cb_lleixa;
    private javax.swing.JComboBox<String> cb_passadis;
    private javax.swing.JMenuItem cerrarsesio;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JComboBox<String> jc_categoria;
    private javax.swing.JTextField jt_actual;
    private javax.swing.JTextField jt_cercar;
    private javax.swing.JTextField jt_condesc;
    private javax.swing.JTextArea jt_desc;
    private javax.swing.JTextField jt_descompte;
    private javax.swing.JTextField jt_estoc;
    private javax.swing.JTextField jt_maxim;
    private javax.swing.JTextField jt_minim;
    private javax.swing.JTextField jt_nom;
    private javax.swing.JTextField jt_preu;
    private javax.swing.JTextField jt_serie;
    private javax.swing.JLabel label_foto;
    private javax.swing.JLabel label_info;
    private javax.swing.JMenuItem opt_crear;
    private javax.swing.JPanel panel_estoc;
    private javax.swing.JTable tbl_prod;
    // End of variables declaration//GEN-END:variables
}
