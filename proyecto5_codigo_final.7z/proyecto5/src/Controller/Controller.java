/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Categoria;
import model.Conexio;
import model.Estoc;
import model.InfoTaula;
import model.Lloc;
import model.ProdLlocEstoc;
import model.Prod_Lloc_Estoc;
import model.Producte;
import model.Serie;
import view.Vista_Magatzem;

/**
 *
 * @author zuh19
 */
public class Controller {
    
    ArrayList<ProdLlocEstoc> mostrarProductes = new ArrayList<ProdLlocEstoc>();
    ArrayList<Prod_Lloc_Estoc> mostrar_all = new ArrayList<Prod_Lloc_Estoc>();
    
    Conexio conexion = new Conexio();
    Connection con = conexion.conectar();
    
    public void LimpiarTabla(DefaultTableModel modelo){
        mostrar_all.clear();
        modelo.setRowCount(0);
    }
    
    public ArrayList<Prod_Lloc_Estoc>  AllProd(){
        mostrar_all.clear();
        String sql="SELECT * FROM tbl_lloc INNER JOIN tbl_estoc ON tbl_estoc.lloc_id=tbl_lloc.lloc_id INNER JOIN "
                + "tbl_producte ON tbl_producte.prod_id=tbl_estoc.prod_id INNER JOIN tbl_serie ON "
                + "tbl_producte.serie_id=tbl_serie.serie_id INNER JOIN tbl_categoria ON "
                + "tbl_serie.categoria_id=tbl_categoria.categoria_id ORDER BY tbl_producte.prod_id";
        Statement st;
        try {
            st=con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            
            while(rs.next()){
            Prod_Lloc_Estoc all = new Prod_Lloc_Estoc();
            
                Producte producte = new Producte();

                Integer id=Integer.valueOf(rs.getString("prod_id"));
                producte.setId(id);
                producte.setNom(rs.getString("prod_nom"));
                producte.setFoto(rs.getString("prod_foto"));
                Integer serie_id=Integer.valueOf(rs.getString("serie_id"));
                producte.setSerie_id(serie_id);
                producte.setDesc(rs.getString("prod_descripcio"));
                Integer descompte=Integer.valueOf(rs.getString("prod_descompte"));
                producte.setDescompte(descompte);
                producte.setPreu(rs.getDouble("prod_preu"));

                Lloc lloc = new Lloc();

                Integer llocid=Integer.valueOf(rs.getString("lloc_id"));
                lloc.setLlocid(llocid);
                lloc.setNumbloc(rs.getString("num_bloc"));
                lloc.setPassadis(rs.getString("num_passadis"));
                lloc.setLleixa(rs.getString("num_lleixa"));

                Estoc estoc = new Estoc();

                estoc.setEstoc_id(Integer.valueOf(rs.getString("estoc_id")));
                estoc.setActual(Integer.valueOf(rs.getString("estoc_q_actual")));
                estoc.setMax(Integer.valueOf(rs.getString("estoc_q_max")));
                estoc.setMin(Integer.valueOf(rs.getString("estoc_q_min")));
                estoc.setProd_id(Integer.valueOf(rs.getString("prod_id")));
                estoc.setLloc_id(Integer.valueOf(rs.getString("lloc_id")));

                Categoria categoria = new Categoria();

                Integer cat_id=Integer.valueOf(rs.getString("categoria_id"));
                categoria.setCategoria_id(cat_id);
                categoria.setCategoria_nom(rs.getString("categoria_nom"));

                Serie serie = new Serie();

                Integer serieid=Integer.valueOf(rs.getString("serie_id"));
                serie.setSerie_id(serieid);
                serie.setSerie_nom(rs.getString("serie_nom"));
                Integer idcat=Integer.valueOf(rs.getString("categoria_id"));
                serie.setCategoria_id(idcat);

                all.setP(producte);
                all.setE(estoc);
                all.setL(lloc);
                all.setC(categoria);
                all.setS(serie);
                mostrar_all.add(all);
            }
        } catch (Exception e) {
        }
              
        return mostrar_all;
    }
    
    public Integer clicktable(DefaultTableModel modelo, Integer row, String id){
        Integer res=0;
        String sql1="SELECT * FROM tbl_lloc INNER JOIN tbl_estoc ON tbl_estoc.lloc_id=tbl_lloc.lloc_id INNER JOIN"+
        " tbl_producte ON tbl_producte.prod_id=tbl_estoc.prod_id INNER JOIN tbl_serie ON tbl_producte.serie_id=tbl_serie.serie_id"+
        " INNER JOIN tbl_categoria ON tbl_categoria.categoria_id=tbl_serie.categoria_id WHERE"+
        " tbl_producte.prod_id='"+id+"'";
        Statement st;
        try {
            st = con.createStatement();
            ResultSet rs = st.executeQuery(sql1);
            rs.next();
            
            ProdLlocEstoc producte = new ProdLlocEstoc();
            
                Integer id_click=Integer.valueOf(rs.getString("prod_id"));
                producte.setId(id_click);
                producte.setNom(rs.getString("prod_nom"));
                producte.setFoto(rs.getString("prod_foto"));
                Integer serie_id=Integer.valueOf(rs.getString("serie_id"));
                producte.setSerie_id(serie_id);
                producte.setDesc(rs.getString("prod_descripcio"));
                Integer descompte=Integer.valueOf(rs.getString("prod_descompte"));
                producte.setDescompte(descompte);
                producte.setBloc(rs.getString("num_bloc"));
                producte.setPassadis(rs.getString("num_passadis"));
                producte.setLleixa(rs.getString("num_lleixa"));
                
                producte.setPreu(rs.getDouble("prod_preu"));
            res=row;
             
        } catch (SQLException ex) {
            Logger.getLogger(Vista_Magatzem.class.getName()).log(Level.SEVERE, null, ex);
        }
        return res;
    }
    
    public ArrayList<Prod_Lloc_Estoc> cercar(DefaultTableModel modelo, String cerca, String select){
        String sql = "";
        boolean cercar=false;
        boolean nada=false;
        if(cerca!=null && select!="Qualsevol"){
            cercar=true;
            sql="SELECT * FROM tbl_lloc INNER JOIN tbl_estoc ON tbl_estoc.lloc_id=tbl_lloc.lloc_id INNER JOIN tbl_producte"
            + " ON tbl_producte.prod_id=tbl_estoc.prod_id INNER JOIN tbl_serie ON tbl_producte.serie_id=tbl_serie.serie_id"
            + " INNER JOIN tbl_categoria ON tbl_categoria.categoria_id=tbl_serie.categoria_id WHERE tbl_producte.prod_nom "
            +"LIKE '%"+cerca+"%' AND tbl_categoria.categoria_nom='"+select+"' ORDER BY tbl_producte.prod_id";
            System.out.println(sql);
            
        }else if(cerca!=null & select=="Qualsevol"){
            cercar=true;
            sql="SELECT * FROM tbl_lloc INNER JOIN tbl_estoc ON tbl_estoc.lloc_id=tbl_lloc.lloc_id INNER JOIN tbl_producte"
            + " ON tbl_producte.prod_id=tbl_estoc.prod_id INNER JOIN tbl_serie ON tbl_producte.serie_id=tbl_serie.serie_id"
            + " INNER JOIN tbl_categoria ON tbl_categoria.categoria_id=tbl_serie.categoria_id WHERE tbl_producte.prod_nom "
            +"LIKE '%"+cerca+"%' ORDER BY tbl_producte.prod_id";
            System.out.println(sql);
        }
        
        Statement st;
        
        try {
            st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            if (!rs.isBeforeFirst() ) {    
                nada=true;
                JOptionPane.showMessageDialog(null,"No se ha encontrado resultados según su búsqueda");
            }else{
                if(nada==false){
                    LimpiarTabla(modelo);
                    while (rs.next()) {
                        Prod_Lloc_Estoc all = new Prod_Lloc_Estoc();
                        
                        Producte producte = new Producte();

                Integer id=Integer.valueOf(rs.getString("prod_id"));
                producte.setId(id);
                producte.setNom(rs.getString("prod_nom"));
                producte.setFoto(rs.getString("prod_foto"));
                Integer serie_id=Integer.valueOf(rs.getString("serie_id"));
                producte.setSerie_id(serie_id);
                producte.setDesc(rs.getString("prod_descripcio"));
                Integer descompte=Integer.valueOf(rs.getString("prod_descompte"));
                producte.setDescompte(descompte);
                producte.setPreu(rs.getDouble("prod_preu"));

                Lloc lloc = new Lloc();

                Integer llocid=Integer.valueOf(rs.getString("lloc_id"));
                lloc.setLlocid(llocid);
                lloc.setNumbloc(rs.getString("num_bloc"));
                lloc.setPassadis(rs.getString("num_passadis"));
                lloc.setLleixa(rs.getString("num_lleixa"));

                Estoc estoc = new Estoc();

                estoc.setEstoc_id(Integer.valueOf(rs.getString("estoc_id")));
                estoc.setActual(Integer.valueOf(rs.getString("estoc_q_actual")));
                estoc.setMax(Integer.valueOf(rs.getString("estoc_q_max")));
                estoc.setMin(Integer.valueOf(rs.getString("estoc_q_min")));
                estoc.setProd_id(Integer.valueOf(rs.getString("prod_id")));
                estoc.setLloc_id(Integer.valueOf(rs.getString("lloc_id")));

                Categoria categoria = new Categoria();

                Integer cat_id=Integer.valueOf(rs.getString("categoria_id"));
                categoria.setCategoria_id(cat_id);
                categoria.setCategoria_nom(rs.getString("categoria_nom"));

                Serie serie = new Serie();

                Integer serieid=Integer.valueOf(rs.getString("serie_id"));
                serie.setSerie_id(serieid);
                serie.setSerie_nom(rs.getString("serie_nom"));
                Integer idcat=Integer.valueOf(rs.getString("categoria_id"));
                serie.setCategoria_id(idcat);

                all.setP(producte);
                all.setE(estoc);
                all.setL(lloc);
                all.setC(categoria);
                all.setS(serie);
                mostrar_all.add(all);
                    }
                    
                    String[] filas = new String[5];

                    for(int i=0;i<=mostrar_all.size()-1;i++){
                        filas[0]=String.valueOf(mostrar_all.get(i).getP().getId());
                        filas[1]=mostrar_all.get(i).getP().getNom();
                        filas[2]=mostrar_all.get(i).getC().getCategoria_nom();
                        filas[3]=mostrar_all.get(i).getS().getSerie_nom();
                        filas[4]=String.valueOf(mostrar_all.get(i).getP().getPreu());
                        modelo.addRow(filas);
                    }
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(Vista_Magatzem.class.getName()).log(Level.SEVERE, null, ex);
        }
        return mostrar_all;
    }
    
    public DefaultTableModel mostrarproductos(DefaultTableModel modelo) {
        
        modelo.setRowCount(0);
            String[] filas = new String[5];
            
            for (int i = 0; i <=mostrar_all.size()-1; i++) {
                
                String id=String.valueOf(mostrar_all.get(i).getP().getId());
                filas[0]=id;
                
                String nom=mostrar_all.get(i).getP().getNom();
                filas[1]=nom;
                                
                String categoria=mostrar_all.get(i).getC().getCategoria_nom();
                filas[2]=categoria;
                
                String serie=mostrar_all.get(i).getS().getSerie_nom();
                filas[3]=serie;
                
                String preu=String.valueOf(mostrar_all.get(i).getP().getPreu());
                filas[4]=preu;
                
                modelo.addRow(filas);
            }
            int rows = modelo.getRowCount();
            return modelo;
    }
    
    public void RegistrarProducte(String nom, String desc, String preu, String descompte, String categoria, String serie, String bloc, String passadis, String lleixa, String max, String actual, String min){
        try {
            con.setAutoCommit(false);
            String sql="SELECT categoria_id FROM tbl_categoria WHERE categoria_nom='"+categoria+"'";
            Statement st;
            st=con.createStatement();
            ResultSet rs=st.executeQuery(sql);
            rs.next();
            String id_categoria=rs.getString("categoria_id");
            
            sql="INSERT INTO tbl_serie(serie_nom, categoria_id) VALUES(?,?)";
            PreparedStatement pst1 = null;
            pst1 = con.prepareStatement(sql);
            pst1.setString(1, serie);
            pst1.setString(2, id_categoria);
            pst1.executeUpdate();
            
            Statement st2=null;
            st2 = con.createStatement();
            String sql_llocid = "SELECT DISTINCT last_insert_id() FROM tbl_serie";
            rs = st2.executeQuery(sql_llocid);
            String serie_id="";
            while(rs.next()){
                serie_id=String.valueOf(rs.getInt(1));
            }
            
            sql="INSERT INTO tbl_producte(prod_nom,prod_foto,serie_id,prod_descripcio,prod_descompte,prod_preu) VALUES (?,?,?,?,?,?)";
            PreparedStatement pst2 = null;
            pst2 = con.prepareStatement(sql);
            pst2.setString(1, nom);
            /* PONER FOTO */
            //pst2.setString(2, foto);
            pst2.setString(3,serie);
            pst2.setString(4,desc);
            pst2.setString(5,descompte);
            pst2.setString(6,preu);
            
            pst2.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public boolean modificar_producte(String nom,String desc,String preu,String descompte,String bloc,String passadis,String lleixa,String categoria,String serie,String id){
        boolean result=false;
        try {
            con.setAutoCommit(false);
            String sql="SELECT lloc_id FROM tbl_lloc WHERE num_bloc='"+bloc+"' AND num_passadis='"+passadis+"' AND num_lleixa='"+lleixa+"'";
            Statement st1;
            st1 = con.createStatement();
            ResultSet rs = st1.executeQuery(sql);
            
            String id_lloc="";
            String id_serie="";
            if (!rs.isBeforeFirst()) {    
                sql="INSERT INTO tbl_lloc(num_bloc,num_passadis,num_lleixa) VALUES(?,?,?)";
                PreparedStatement pst1 = null;
                pst1 = con.prepareStatement(sql);
                pst1.setString(1, bloc);
                pst1.setString(2, passadis);
                pst1.setString(3, lleixa);
                pst1.executeUpdate();
                
                Statement st2=null;
                st2 = con.createStatement();
                String sql_llocid = "SELECT DISTINCT last_insert_id() FROM tbl_lloc";
                rs = st2.executeQuery(sql_llocid);
                while(rs.next()){
                    id_lloc=String.valueOf(rs.getInt(1));
                }
            }else{
                rs.next();
                id_lloc=rs.getString("lloc_id");
            }
            
            sql="SELECT categoria_id FROM tbl_categoria WHERE categoria_nom='"+categoria+"'";
            
            Statement st3=null;
            st3 = con.createStatement();
            rs = st3.executeQuery(sql);
            
            rs.next();
            
            String cat_id=rs.getString("categoria_id");
            
            System.out.println("Categoria bien");
            
            sql="SELECT serie_id FROM tbl_serie WHERE serie_nom='"+serie+"' AND categoria_id='"+cat_id+"'";
            
            Statement st4=null;
            st4 = con.createStatement();
            rs = st4.executeQuery(sql);
            
            if (!rs.isBeforeFirst()) {    
                 sql="INSERT INTO tbl_serie(serie_nom,categoria_id) VALUES(?,?)";
                PreparedStatement pst2 = null;
                pst2 = con.prepareStatement(sql);
                pst2.setString(1, serie);
                pst2.setString(2, cat_id);
                pst2.executeUpdate();
                
                Statement st5=null;
                st5 = con.createStatement();
                String sql_serie_id = "SELECT DISTINCT last_insert_id() FROM tbl_serie";
                rs = st5.executeQuery(sql_serie_id);
                while(rs.next()){
                    id_serie=String.valueOf(rs.getInt(1));
                }
            }else{
                rs.next();
                id_serie=rs.getString("serie_id");
            }
            
            sql="UPDATE tbl_estoc SET lloc_id='"+id_lloc+"' WHERE prod_id='"+id+"'";
            Statement st6;
            st6 = con.createStatement();
            st6.executeUpdate(sql);
            
            
            String sql1="UPDATE tbl_producte SET prod_nom='"+nom+"',prod_descripcio='"+desc+"',prod_preu='"+preu+"',"
            +"prod_descompte='"+descompte+"',serie_id='"+id_serie+"' WHERE prod_id='"+id+"'";
            Statement st7;
            st7 = con.createStatement();
            st7.executeUpdate(sql1);
            
            con.commit();
            result=true;
        } catch (SQLException ex) {
            try {
                con.rollback();
                JOptionPane.showMessageDialog(null,"Error, aquest producte no s'ha pogut modificar");
                result=false;
                Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex1) {
                Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }
        return result;
    }
    
    public void restar_estoc(Integer num, Integer id){
        try {
            String sql="UPDATE tbl_estoc SET estoc_q_actual='"+num+"' WHERE prod_id='"+id+"'";
            Statement st;
            st = con.createStatement();
            st.executeUpdate(sql);
            
            Statement st1;
            String sql1="SELECT * FROM tbl_estoc WHERE prod_id='"+id+"'";
            st1 = con.createStatement();
            ResultSet rs = st1.executeQuery(sql1);
            rs.next();
            Integer min=Integer.valueOf(rs.getString("estoc_q_min"));
            Integer actual=Integer.valueOf(rs.getString("estoc_q_actual"));
            
            Integer dif=actual-min;
            if(dif<=10){
                JOptionPane.showMessageDialog(null,"Este producto está muy cerca de su mínimo");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void sumar_estoc(Integer num, Integer id){
        try {
            String sql="UPDATE tbl_estoc SET estoc_q_actual='"+num+"' WHERE prod_id='"+id+"'";
            Statement st;
            st = con.createStatement();
            st.executeUpdate(sql);
            
            Statement st1;
            String sql1="SELECT * FROM tbl_estoc WHERE prod_id='"+id+"'";
            st1 = con.createStatement();
            ResultSet rs = st1.executeQuery(sql1);
            rs.next();
            Integer max=Integer.valueOf(rs.getString("estoc_q_max"));
            Integer actual=Integer.valueOf(rs.getString("estoc_q_actual"));
            Integer dif=max-actual;
            if(dif<=10){
                JOptionPane.showMessageDialog(null,"Este producto está muy cerca de su estoc máximo");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
 
    public void eliminar(String id){
        try {
            con.setAutoCommit(false);
            String sql = "SELECT lloc_id FROM tbl_estoc WHERE prod_id='"+id+"'";
            Statement st5=null;
            st5 = con.createStatement();
            ResultSet rs = st5.executeQuery(sql);
            String lloc_id="";
            while(rs.next()){
                lloc_id=rs.getString("lloc_id");
            }
            
            sql="DELETE FROM tbl_estoc WHERE prod_id='"+id+"'";
            Statement st;
            st = con.createStatement();
            st.executeUpdate(sql);
            
            sql="DELETE FROM tbl_lloc WHERE lloc_id='"+lloc_id+"'";
            Statement st1;
            st1 = con.createStatement();
            st1.executeUpdate(sql);
            
            sql="DELETE FROM tbl_producte WHERE prod_id='"+id+"'";
            Statement st2;
            st2 = con.createStatement();
            st2.executeUpdate(sql);
            con.commit();
            JOptionPane.showMessageDialog(null,"Producte eliminat");
        } catch (Exception e) {
            try {
                con.rollback();
                JOptionPane.showMessageDialog(null,"Error, aquest producte no s'ha pogut eliminar");
            } catch (SQLException ex) {
                Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
}