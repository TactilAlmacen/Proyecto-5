/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author zuh19
 */
public class Lloc {
    Integer llocid;
    String numbloc;
    String passadis;
    String lleixa;

    public Lloc() {
    }

    public Integer getLlocid() {
        return llocid;
    }

    public void setLlocid(Integer llocid) {
        this.llocid = llocid;
    }

    public String getNumbloc() {
        return numbloc;
    }

    public void setNumbloc(String numbloc) {
        this.numbloc = numbloc;
    }

    public String getPassadis() {
        return passadis;
    }

    public void setPassadis(String passadis) {
        this.passadis = passadis;
    }

    public String getLleixa() {
        return lleixa;
    }

    public void setLleixa(String lleixa) {
        this.lleixa = lleixa;
    }

    public Lloc(Integer llocid, String numbloc, String passadis, String lleixa) {
        this.llocid = llocid;
        this.numbloc = numbloc;
        this.passadis = passadis;
        this.lleixa = lleixa;
    }

    
}
