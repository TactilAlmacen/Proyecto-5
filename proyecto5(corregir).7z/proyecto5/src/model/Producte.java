/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author zuh19
 */
public class Producte {
    
    Integer id;
    String nom;
    String foto;
    Integer serie_id;
    String desc;
    Integer descompte;
    Double preu;

    public Producte() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    public Integer getSerie_id() {
        return serie_id;
    }

    public void setSerie_id(Integer serie_id) {
        this.serie_id = serie_id;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public Integer getDescompte() {
        return descompte;
    }

    public void setDescompte(Integer descompte) {
        this.descompte = descompte;
    }

    public Double getPreu() {
        return preu;
    }

    public void setPreu(Double preu) {
        this.preu = preu;
    }

    public Producte(Integer id, String nom, String foto, Integer serie_id, String desc, Integer descompte, Double preu) {
        this.id = id;
        this.nom = nom;
        this.foto = foto;
        this.serie_id = serie_id;
        this.desc = desc;
        this.descompte = descompte;
        this.preu = preu;
    }

}
