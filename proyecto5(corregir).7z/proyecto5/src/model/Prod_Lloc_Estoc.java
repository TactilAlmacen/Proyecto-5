/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;


/**
 *
 * @author zuh19
 */


public class Prod_Lloc_Estoc {
    private Producte p;
    private Estoc e;
    private Lloc l;
    private Categoria c;
    private Serie s;
    
    public Prod_Lloc_Estoc() {
    }

    public Prod_Lloc_Estoc(Producte p, Estoc e, Lloc l, Categoria c, Serie s) {
        this.p = p;
        this.e = e;
        this.l = l;
        this.c = c;
        this.s = s;
    }

    public Producte getP() {
        return p;
    }

    public void setP(Producte p) {
        this.p = p;
    }

    public Estoc getE() {
        return e;
    }

    public void setE(Estoc e) {
        this.e = e;
    }

    public Lloc getL() {
        return l;
    }

    public void setL(Lloc l) {
        this.l = l;
    }

    public Categoria getC() {
        return c;
    }

    public void setC(Categoria c) {
        this.c = c;
    }

    public Serie getS() {
        return s;
    }

    public void setS(Serie s) {
        this.s = s;
    }
   
    
}
