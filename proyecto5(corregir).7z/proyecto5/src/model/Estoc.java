/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author zuh19
 */
public class Estoc {
    Integer estoc_id;
    Integer max;
    Integer actual;
    Integer min;
    Integer prod_id;
    Integer lloc_id;
    
    public Estoc() {
    }

    public Estoc(Integer estoc_id, Integer max, Integer actual, Integer min, Integer prod_id, Integer lloc_id) {
        this.estoc_id = estoc_id;
        this.max = max;
        this.actual = actual;
        this.min = min;
        this.prod_id = prod_id;
        this.lloc_id = lloc_id;
    }

    public Integer getEstoc_id() {
        return estoc_id;
    }

    public void setEstoc_id(Integer estoc_id) {
        this.estoc_id = estoc_id;
    }

    public Integer getMax() {
        return max;
    }

    public void setMax(Integer max) {
        this.max = max;
    }

    public Integer getActual() {
        return actual;
    }

    public void setActual(Integer actual) {
        this.actual = actual;
    }

    public Integer getMin() {
        return min;
    }

    public void setMin(Integer min) {
        this.min = min;
    }

    public Integer getProd_id() {
        return prod_id;
    }

    public void setProd_id(Integer prod_id) {
        this.prod_id = prod_id;
    }

    public Integer getLloc_id() {
        return lloc_id;
    }

    public void setLloc_id(Integer lloc_id) {
        this.lloc_id = lloc_id;
    }

    
}
