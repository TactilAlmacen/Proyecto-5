/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author zuh19
 */
public class InfoTaula {
    String nom;
    String categoria;
    String serie;

    public InfoTaula() {
    }

    public InfoTaula(String nom, String categoria, String serie) {
        this.nom = nom;
        this.categoria = categoria;
        this.serie = serie;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getSerie() {
        return serie;
    }

    public void setSerie(String serie) {
        this.serie = serie;
    }
    
    
}