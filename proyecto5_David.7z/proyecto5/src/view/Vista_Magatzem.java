/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.awt.Image;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.text.DefaultCaret;
import model.Conexio;
import model.InfoTaula;
import model.Producte;

/**
 *
 * @author zuh19
 */
public class Vista_Magatzem extends javax.swing.JFrame {

    ArrayList<InfoTaula> listaProducte = new ArrayList<InfoTaula>();
    ArrayList<Producte> mostrarProductes = new ArrayList<Producte>();
    
    Conexio conexion = new Conexio();
    Connection con = conexion.conectar();
    
    int j=0;
    
    public Vista_Magatzem() {
        initComponents();
        AllProd();
        mostrar(j);
        btn_mostrar.setVisible(false);
        MostrarProducte((DefaultTableModel)this.tbl_prod.getModel());
    }
    
    public void activar_desactivar(boolean t){
        this.btn_ultim.setEnabled(t);
        this.btn_seguent.setEnabled(t);
        this.btn_primer.setEnabled(!t);
        this.btn_anterior.setEnabled(!t);
        
    }
    
    private void LimpiarTabla(DefaultTableModel modelo){
        listaProducte.clear();
        modelo.setRowCount(0);
    }

    private void AllProd(){
        String sql="SELECT * FROM tbl_producte";
        Statement st;
        
        try {
            st=con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            
            while(rs.next()){
            
            Producte producte = new Producte();
            
            producte.setNom(rs.getString("prod_nom"));
            producte.setFoto(rs.getString("prod_foto"));
            Integer serie_id=Integer.valueOf(rs.getString("serie_id"));
            producte.setSerie_id(serie_id);
            producte.setDesc(rs.getString("prod_descripcio"));
            Integer descompte=Integer.valueOf(rs.getString("prod_descompte"));
            producte.setDescompte(descompte);
            producte.setPreu(rs.getDouble("prod_preu"));
         
            mostrarProductes.add(producte);
            }
            activar_desactivar(true);
        } catch (Exception e) {
        }
    }
    
    public void mostrar(int index){
        this.jt_nom.setText(mostrarProductes.get(index).getNom());
        this.jt_desc.setText(mostrarProductes.get(index).getDesc());
        this.jt_preu.setText(String.valueOf(mostrarProductes.get(index).getPreu()));
        this.jt_descompte.setText(String.valueOf(mostrarProductes.get(index).getDescompte()));
    }
    
    private void MostrarProducte(DefaultTableModel modelo){
        
        String sql = "SELECT tbl_categoria.categoria_nom, tbl_serie.serie_nom, tbl_producte.prod_nom FROM tbl_categoria INNER JOIN tbl_serie ON tbl_categoria.categoria_id=tbl_serie.categoria_id INNER JOIN tbl_producte ON tbl_producte.serie_id=tbl_serie.serie_id";
        Statement st;
            
        try {
            st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
               
                InfoTaula taula = new InfoTaula();
                taula.setNom(rs.getString("prod_nom"));
                taula.setCategoria(rs.getString("categoria_nom"));
                taula.setSerie(rs.getString("serie_nom"));
                listaProducte.add(taula);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Vista_Magatzem.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        String[] filas = new String[3];
        
        for(int i=0;i<listaProducte.size();i++){
            filas[0]= listaProducte.get(i).getNom();
            filas[1]= listaProducte.get(i).getCategoria();
            filas[2]= listaProducte.get(i).getSerie();
            modelo.addRow(filas);
        }
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jt_nom = new javax.swing.JTextField();
        jt_preu = new javax.swing.JTextField();
        jt_descompte = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_prod = new javax.swing.JTable();
        jt_cercar = new javax.swing.JTextField();
        btn_cercar = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        label_foto = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jt_desc = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        btn_mostrar = new javax.swing.JButton();
        btn_primer = new javax.swing.JButton();
        btn_anterior = new javax.swing.JButton();
        btn_seguent = new javax.swing.JButton();
        btn_ultim = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Nom");

        jLabel2.setText("Descripció");

        jLabel3.setText("Preu");

        jLabel4.setText("Descompte");

        jt_nom.setEditable(false);

        jt_preu.setEditable(false);
        jt_preu.setToolTipText("Mostrat en €");

        jt_descompte.setEditable(false);
        jt_descompte.setToolTipText("");

        tbl_prod.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nom", "Categoria", "Sèrie"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_prod.setUpdateSelectionOnSort(false);
        tbl_prod.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_prodMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_prod);

        jt_cercar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jt_cercarActionPerformed(evt);
            }
        });

        btn_cercar.setText("Cercar");
        btn_cercar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cercarActionPerformed(evt);
            }
        });

        jLabel8.setText("Cercador");

        jPanel1.setBackground(new java.awt.Color(153, 153, 153));

        label_foto.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(label_foto, javax.swing.GroupLayout.DEFAULT_SIZE, 176, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(label_foto, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jLabel9.setText("INFORMACIÓ PRODUCTE");

        jt_desc.setEditable(false);
        jt_desc.setToolTipText("Breu descripció del producte");

        jLabel5.setText("€");

        jLabel6.setText("%");

        btn_mostrar.setText("Mostrar todos los productos");
        btn_mostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_mostrarActionPerformed(evt);
            }
        });

        btn_primer.setText("<<");
        btn_primer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_primerActionPerformed(evt);
            }
        });

        btn_anterior.setText("<");
        btn_anterior.setToolTipText("");
        btn_anterior.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_anteriorActionPerformed(evt);
            }
        });

        btn_seguent.setText(">");
        btn_seguent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_seguentActionPerformed(evt);
            }
        });

        btn_ultim.setText(">>");
        btn_ultim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ultimActionPerformed(evt);
            }
        });

        jLabel7.setText("Preu (amb descompte)");

        jTextField1.setEditable(false);

        jLabel10.setText("€");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(77, 77, 77)
                                .addComponent(jLabel9)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(jLabel7)
                                        .addGap(15, 15, 15))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel3)
                                            .addComponent(jLabel4)
                                            .addComponent(jLabel2)
                                            .addComponent(jLabel1))
                                        .addGap(18, 18, 18)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jt_nom)
                                        .addComponent(jt_desc, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(jTextField1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 91, Short.MAX_VALUE)
                                            .addComponent(jt_descompte, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jt_preu, javax.swing.GroupLayout.Alignment.LEADING))
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel10))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 73, Short.MAX_VALUE)
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(34, 34, 34)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addGap(49, 49, 49)
                                .addComponent(jt_cercar, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btn_cercar))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 363, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(21, 21, 21))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(111, 111, 111)
                        .addComponent(btn_primer)
                        .addGap(48, 48, 48)
                        .addComponent(btn_anterior)
                        .addGap(50, 50, 50)
                        .addComponent(btn_seguent)
                        .addGap(37, 37, 37)
                        .addComponent(btn_ultim)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btn_mostrar)
                        .addGap(112, 112, 112))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jt_cercar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_cercar)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 188, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jt_nom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(jt_desc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(jt_preu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(jt_descompte, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(btn_mostrar)
                        .addContainerGap(47, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_primer)
                            .addComponent(btn_anterior)
                            .addComponent(btn_seguent)
                            .addComponent(btn_ultim))
                        .addGap(36, 36, 36))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jt_cercarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jt_cercarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jt_cercarActionPerformed

    private void tbl_prodMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_prodMouseClicked
        // TODO add your handling code here:
        int index =tbl_prod.getSelectedRow();
        TableModel model= tbl_prod.getModel();
        String nombre_col=model.getValueAt(index,0).toString();
        String categoria_col=model.getValueAt(index,1).toString();
        String serie_col=model.getValueAt(index,2).toString();
        
        String sql1="SELECT * FROM tbl_producte INNER JOIN tbl_serie ON tbl_producte.serie_id=tbl_serie.serie_id INNER JOIN tbl_categoria ON tbl_categoria.categoria_id=tbl_serie.categoria_id WHERE tbl_producte.prod_nom='"+nombre_col+"' AND tbl_categoria.categoria_nom='"+categoria_col+"' AND tbl_serie.serie_nom='"+serie_col+"'";
        Statement st;
            
        try {
            st = con.createStatement();
            ResultSet rs = st.executeQuery(sql1);
            rs.next();
            
            Producte producte = new Producte();
            
                producte.setNom(rs.getString("prod_nom"));
                producte.setFoto(rs.getString("prod_foto"));
                Integer serie_id=Integer.valueOf(rs.getString("serie_id"));
                producte.setSerie_id(serie_id);
                producte.setDesc(rs.getString("prod_descripcio"));
                Integer descompte=Integer.valueOf(rs.getString("prod_descompte"));
                producte.setDescompte(descompte);
                producte.setPreu(rs.getDouble("prod_preu"));
                
            jt_nom.setText(producte.getNom());
            jt_desc.setText(producte.getDesc());
            jt_preu.setText(String.valueOf(producte.getPreu()));
            jt_descompte.setText(String.valueOf(producte.getDescompte()));
            
            
            
        } catch (SQLException ex) {
            Logger.getLogger(Vista_Magatzem.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_tbl_prodMouseClicked

    private void btn_cercarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cercarActionPerformed
        // TODO add your handling code here:
        
        if(jt_cercar.getText()==null || jt_cercar.getText().length()==0){
            JOptionPane.showMessageDialog(null, "Para poder buscar productos, antes introduzca el producto a buscar");
        }else{
            LimpiarTabla((DefaultTableModel)this.tbl_prod.getModel());
            DefaultTableModel modelo = (DefaultTableModel) tbl_prod.getModel();
            String cerca=jt_cercar.getText();
            String sql="SELECT * FROM tbl_producte INNER JOIN tbl_serie ON tbl_producte.serie_id=tbl_serie.serie_id INNER JOIN tbl_categoria ON tbl_categoria.categoria_id=tbl_serie.categoria_id WHERE tbl_producte.prod_nom LIKE '%"+cerca+"%'";
            
            Statement st;
            
            try {
                st = con.createStatement();
                ResultSet rs = st.executeQuery(sql);
                while (rs.next()) {

                    InfoTaula taula = new InfoTaula();
                    taula.setNom(rs.getString("prod_nom"));
                    taula.setCategoria(rs.getString("categoria_nom"));
                    taula.setSerie(rs.getString("serie_nom"));
                    listaProducte.add(taula);
                }
            } catch (SQLException ex) {
                Logger.getLogger(Vista_Magatzem.class.getName()).log(Level.SEVERE, null, ex);
            }

            String[] filas = new String[3];

            for(int i=0;i<listaProducte.size();i++){
                filas[0]= listaProducte.get(i).getNom();
                filas[1]= listaProducte.get(i).getCategoria();
                filas[2]= listaProducte.get(i).getSerie();
                modelo.addRow(filas);
            }
            btn_mostrar.setVisible(true);
        }
    }//GEN-LAST:event_btn_cercarActionPerformed

    private void btn_mostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_mostrarActionPerformed
        // TODO add your handling code here:
        LimpiarTabla((DefaultTableModel)this.tbl_prod.getModel());
        MostrarProducte((DefaultTableModel)this.tbl_prod.getModel());
        btn_mostrar.setVisible(false);
        jt_cercar.setText("");
    }//GEN-LAST:event_btn_mostrarActionPerformed

    private void btn_primerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_primerActionPerformed
        // TODO add your handling code here:
        activar_desactivar(true);
    }//GEN-LAST:event_btn_primerActionPerformed

    private void btn_seguentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_seguentActionPerformed
        // TODO add your handling code here:
        j++;
        mostrar(j);
        if(j==mostrarProductes.size()-1){
            activar_desactivar(false);
        }
    }//GEN-LAST:event_btn_seguentActionPerformed

    private void btn_anteriorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_anteriorActionPerformed
        // TODO add your handling code here:
        j--;
        mostrar(j);
        if(j==0){
            activar_desactivar(true);
        }
    }//GEN-LAST:event_btn_anteriorActionPerformed

    private void btn_ultimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ultimActionPerformed
        // TODO add your handling code here:
        activar_desactivar(false);
    }//GEN-LAST:event_btn_ultimActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Vista_Magatzem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Vista_Magatzem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Vista_Magatzem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Vista_Magatzem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Vista_Magatzem().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_anterior;
    private javax.swing.JButton btn_cercar;
    private javax.swing.JButton btn_mostrar;
    private javax.swing.JButton btn_primer;
    private javax.swing.JButton btn_seguent;
    private javax.swing.JButton btn_ultim;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jt_cercar;
    private javax.swing.JTextField jt_desc;
    private javax.swing.JTextField jt_descompte;
    private javax.swing.JTextField jt_nom;
    private javax.swing.JTextField jt_preu;
    private javax.swing.JLabel label_foto;
    private javax.swing.JTable tbl_prod;
    // End of variables declaration//GEN-END:variables
}
