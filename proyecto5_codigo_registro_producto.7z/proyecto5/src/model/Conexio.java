/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author zuh19
 */
public class Conexio {

    public String db="bd_estoc";
    public String url="jdbc:mysql://127.0.0.1/" +db;
    public String user="root";
    public String pass="";

    public Conexio() {
    }
    
    public Connection conectar(){
        Connection link=null;
        
        try {
            //Usar la classe DriverManager para eso he de importar el Driver 
            //a traves de un fichero jar
            
            Class.forName("org.gjt.mm.mysql.Driver");
            link=DriverManager.getConnection(this.url, this.user, this.pass);
                
        } catch (ClassNotFoundException e) {
            JOptionPane.showConfirmDialog(null, e);
            JOptionPane.showMessageDialog(null, "conexion erronea");
            
        } catch (SQLException e) {
            JOptionPane.showConfirmDialog(null, e);
            JOptionPane.showMessageDialog(null, "conexion erronea");
        }
        
       return link;
    }

}
