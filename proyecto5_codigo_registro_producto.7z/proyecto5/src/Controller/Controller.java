/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Conexio;
import model.InfoTaula;
import model.ProdLlocEstoc;
import view.Vista_Magatzem;

/**
 *
 * @author zuh19
 */
public class Controller {
    
    ArrayList<InfoTaula> listaProducte = new ArrayList<InfoTaula>();
    ArrayList<ProdLlocEstoc> mostrarProductes = new ArrayList<ProdLlocEstoc>();
    
    Conexio conexion = new Conexio();
    Connection con = conexion.conectar();
    
    public void LimpiarTabla(DefaultTableModel modelo){
        listaProducte.clear();
        mostrarProductes.clear();
        modelo.setRowCount(0);
    }
    
    public Integer clicktable(DefaultTableModel modelo, Integer row, String id){
        Integer res=0;
        String sql1="SELECT * FROM tbl_lloc INNER JOIN tbl_estoc ON tbl_estoc.lloc_id=tbl_lloc.lloc_id INNER JOIN"+
        " tbl_producte ON tbl_producte.prod_id=tbl_estoc.prod_id INNER JOIN tbl_serie ON tbl_producte.serie_id=tbl_serie.serie_id"+
        " INNER JOIN tbl_categoria ON tbl_categoria.categoria_id=tbl_serie.categoria_id WHERE"+
        " tbl_producte.prod_id='"+id+"'";
        Statement st;
        try {
            st = con.createStatement();
            ResultSet rs = st.executeQuery(sql1);
            rs.next();
            
            ProdLlocEstoc producte = new ProdLlocEstoc();
            
                Integer id_click=Integer.valueOf(rs.getString("prod_id"));
                producte.setId(id_click);
                producte.setNom(rs.getString("prod_nom"));
                producte.setFoto(rs.getString("prod_foto"));
                Integer serie_id=Integer.valueOf(rs.getString("serie_id"));
                producte.setSerie_id(serie_id);
                producte.setDesc(rs.getString("prod_descripcio"));
                Integer descompte=Integer.valueOf(rs.getString("prod_descompte"));
                producte.setDescompte(descompte);
                producte.setBloc(rs.getString("num_bloc"));
                producte.setPassadis(rs.getString("num_passadis"));
                producte.setLleixa(rs.getString("num_lleixa"));
                
                producte.setPreu(rs.getDouble("prod_preu"));
            res=row;
             
        } catch (SQLException ex) {
            Logger.getLogger(Vista_Magatzem.class.getName()).log(Level.SEVERE, null, ex);
        }
        return res;
    }
    
    public ArrayList<ProdLlocEstoc> cercar(DefaultTableModel modelo, String cerca, String select){
        String sql = "";
        boolean cercar=false;
        boolean nada=false;
        if(cerca!=null && select!="Qualsevol"){
            cercar=true;
            sql="SELECT * FROM tbl_lloc INNER JOIN tbl_estoc ON tbl_estoc.lloc_id=tbl_lloc.lloc_id INNER JOIN tbl_producte"
            + " ON tbl_producte.prod_id=tbl_lloc.lloc_id INNER JOIN tbl_serie ON tbl_producte.serie_id=tbl_serie.serie_id"
            + " INNER JOIN tbl_categoria ON tbl_categoria.categoria_id=tbl_serie.categoria_id WHERE tbl_producte.prod_nom "
            +"LIKE '%"+cerca+"%' AND tbl_categoria.categoria_nom LIKE '%"+select+"%'";
            
        }else if(cerca!=null & select=="Qualsevol"){
            cercar=true;
            sql="SELECT * FROM tbl_producte INNER JOIN tbl_serie ON tbl_producte.serie_id=tbl_serie.serie_id INNER JOIN"
            +" tbl_categoria ON tbl_categoria.categoria_id=tbl_serie.categoria_id WHERE tbl_producte.prod_nom "
            +"LIKE '%"+cerca+"%'";
        }
        
        Statement st;
        
        try {
            st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            if (!rs.isBeforeFirst() ) {    
                nada=true;
                JOptionPane.showMessageDialog(null,"No se ha encontrado resultados según su búsqueda");
            }else{
                if(nada==false){
                    LimpiarTabla(modelo);
                    while (rs.next()) {
                        ProdLlocEstoc producte = new ProdLlocEstoc();
                        Integer id=Integer.valueOf(rs.getString("prod_id"));
                        producte.setId(id);
                        producte.setNom(rs.getString("prod_nom"));
                        producte.setFoto(rs.getString("prod_foto"));
                        Integer serie_id=Integer.valueOf(rs.getString("serie_id"));
                        producte.setSerie_id(serie_id);
                        producte.setDesc(rs.getString("prod_descripcio"));
                        Integer descompte=Integer.valueOf(rs.getString("prod_descompte"));
                        producte.setDescompte(descompte);
                        producte.setPreu(rs.getDouble("prod_preu"));
                        producte.setBloc(rs.getString("num_bloc"));
                        producte.setPassadis(rs.getString("num_passadis"));
                        producte.setLleixa(rs.getString("num_lleixa"));
                        

                        mostrarProductes.add(producte);
                        InfoTaula taula = new InfoTaula();
                        taula.setId(Integer.valueOf(rs.getString("prod_id")));
                        taula.setNom(rs.getString("prod_nom"));
                        taula.setCategoria(rs.getString("categoria_nom"));
                        taula.setSerie(rs.getString("serie_nom"));
                        Double precio= rs.getDouble("prod_preu");
                        taula.setPreu(precio);
                        listaProducte.add(taula);
                    }
                    
                    String[] filas = new String[5];

                    for(int i=0;i<listaProducte.size();i++){
                        String s=String.valueOf(listaProducte.get(i).getId());
                        filas[0]= s;
                        filas[1]= listaProducte.get(i).getNom();
                        filas[2]= listaProducte.get(i).getCategoria();
                        filas[3]= listaProducte.get(i).getSerie();
                        filas[4]= String.valueOf(listaProducte.get(i).getPreu());
                        modelo.addRow(filas);
                    }
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(Vista_Magatzem.class.getName()).log(Level.SEVERE, null, ex);
        }
        return mostrarProductes;
    }
    
    public void mostrarproductos(DefaultTableModel modelo) {
        String sql = "";
        
            sql = "SELECT tbl_categoria.categoria_nom, tbl_serie.serie_nom, tbl_producte.prod_nom, tbl_producte.prod_preu, "
            +"tbl_producte.prod_id FROM tbl_categoria INNER JOIN tbl_serie ON tbl_categoria.categoria_id=tbl_serie.categoria_id INNER JOIN "
            +"tbl_producte ON tbl_producte.serie_id=tbl_serie.serie_id";
       
        System.out.println(sql);
        Statement st;
        
        try {
            st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
                    LimpiarTabla(modelo);
                    while (rs.next()) {
                        InfoTaula taula = new InfoTaula();
                        taula.setId(Integer.valueOf(rs.getString("prod_id")));
                        taula.setNom(rs.getString("prod_nom"));
                        taula.setCategoria(rs.getString("categoria_nom"));
                        taula.setSerie(rs.getString("serie_nom"));
                        taula.setPreu(rs.getDouble("prod_preu"));
                        listaProducte.add(taula);
                    }
                    
                    String[] filas = new String[5];

                    for(int i=0;i<listaProducte.size();i++){
                        String s=String.valueOf(listaProducte.get(i).getId());
                        filas[0]= s;
                        filas[1]= listaProducte.get(i).getNom();
                        filas[2]= listaProducte.get(i).getCategoria();
                        filas[3]= listaProducte.get(i).getSerie();
                        filas[4]= String.valueOf(listaProducte.get(i).getPreu());
                        modelo.addRow(filas);
                    }
        } catch (SQLException ex) {
            Logger.getLogger(Vista_Magatzem.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void RegistrarProducte(String nom, String desc, Double preu, Integer descompte){
        
    }
    
    public boolean modificar_producte(String nom,String desc,String preu,String descompte,String id){
        boolean result=false;
        try {
            String sql="UPDATE tbl_producte SET prod_nom='"+nom+"',prod_descripcio='"+desc+"',prod_preu='"+preu+"',"
            +"prod_descompte='"+descompte+"' WHERE prod_id='"+id+"'";
            Statement st;
            st = con.createStatement();
            st.executeUpdate(sql);
            result=true;
        } catch (SQLException ex) {
            Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result;
    }
    
}


